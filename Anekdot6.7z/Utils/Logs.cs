﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anekdoti.Utils
{
    static class Logs
    {
        public static void Log(object message, ConsoleColor color = ConsoleColor.White)
        {
            string _message = message.ToString();
            Console.ForegroundColor = color;
            Console.Write(_message);
        }
        public static void LogInfo(object message)
        {
            Log("[INFO]: ", ConsoleColor.Cyan);
            Log(message + "\n");
        }
        public static void LogSystem(object message)
        {
            Log("[SYSTEM]: ", ConsoleColor.Yellow);
            Log(message + "\n");
        }
        public static void NextLine()
        {
            Log("\n");
        }
    }
}
