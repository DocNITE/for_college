﻿using Database;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static Anekdoti.Utils.Logs;

namespace Anekdoti.ViewModel
{
    public class PersonViewModel
    {
        public List<Person> ListPerson = new List<Person>();
        public string FileName = "PersonData.json";
        public PersonViewModel(RoleViewModel roles)
        {
            ListPerson = LoadData(roles);
        }
        public List<Person> LoadDataModel(RoleViewModel roles)
        {
            var _alist = new List<Person>();

            _alist.Add(
            new Person
            {
                Id = 1,
                RoleId = roles.GetRoleWithId(1),
                FirstName = "Иван",
                LastName = "Иванов",
                Birthday = new DateTime(1980, 02, 28)
            });
            _alist.Add(
            new Person
            {
                Id = 2,
                RoleId = roles.GetRoleWithId(2),
                FirstName = "Петр",
                LastName = "Петров",
                Birthday = new DateTime(1981, 03, 20)
            });

            _alist.Add(
            new Person
            {
                Id = 3,
                RoleId = roles.GetRoleWithId(3),
                FirstName = "Виктор",
                LastName = "Викторов",
                Birthday = new DateTime(1982, 04, 15)
            });
            _alist.Add(
            new Person
            {
                Id = 4,
                RoleId = roles.GetRoleWithId(3),
                FirstName = "Сидор",
                LastName = "Сидоров",
                Birthday = new DateTime(1983, 05, 10)
            });
            _alist.Add(
            new Person
            {
                Id = 5,
                RoleId = roles.GetRoleWithId(4),
                FirstName = "Кирил",
                LastName = "Боев",
                Birthday = new DateTime(1983, 05, 10)
            });
            _alist.Add(
            new Person
            {
                Id = 6,
                RoleId = roles.GetRoleWithId(5),
                FirstName = "Максим",
                LastName = "Кожевников",
                Birthday = new DateTime(1983, 05, 10)
            });

            return _alist;
        }
        public void SaveData()
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true
            };

            var _fileName = FileName;
            using (FileStream fs = new FileStream(_fileName, FileMode.OpenOrCreate))
            {
                JsonSerializer.Serialize(fs, ListPerson, options);
                LogInfo("Data was saved!");
            }
        }
        public List<Person> LoadData(RoleViewModel roles)
        {
            using (FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate))
            {
                List<Person> info = JsonSerializer.Deserialize<List<Person>>(fs);
                if (info == null)
                    return LoadDataModel(roles);
                else
                    return info;
            }
        }
    }
}
