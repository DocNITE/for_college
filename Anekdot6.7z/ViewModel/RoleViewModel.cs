﻿using Database;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using static Anekdoti.Utils.Logs;

namespace Anekdoti.ViewModel
{
    public class RoleViewModel
    {
        public List<Role> ListRole = new List<Role>();
        public string FileName = "RoleData.json";
        public RoleViewModel()
        {
            // Load from json (da-da)
            ListRole = LoadData();
        }
        public List<Role> LoadDataModel()
        {
            var _alist = new List<Role>();

            _alist.Add(new Role
            {
                Id = 1,
                Name = "Директор"
            });
            _alist.Add(new Role
            {
                Id = 2,
                Name = "Бухгалтер"
            });
            _alist.Add(new Role
            {
                Id = 3,
                Name = "Менеджер"
            });
            _alist.Add(new Role
            {
                Id = 4,
                Name = "Кскер"
            });
            _alist.Add(new Role
            {
                Id = 5,
                Name = "Чурка"
            });

            return _alist;
        }
        public Role GetRoleWithId(int index)
        {
           for(int i = 0; i < ListRole.Count; i++)
           {
                if (ListRole[i].Id == index)
                {
                    return ListRole[i];
                } 
           }

            return new Role(0, "NULL"); // Чтобы не сломалось все!
        }
        public void SaveData()
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true
            };

            var _fileName = FileName;
            using (FileStream fs = new FileStream(_fileName, FileMode.OpenOrCreate))
            {
                JsonSerializer.Serialize(fs, ListRole, options);
                LogInfo("Data was saved!");
            }
        }
        public List<Role> LoadData()
        {
            using (FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate))
            {
                List<Role> info = JsonSerializer.Deserialize<List<Role>>(fs);
                if (info == null)
                    return LoadDataModel();
                else
                    return info;
            }
        }
    }
}
